import boto3
import json

from io import BytesIO


boto3 = boto3.Session()
bucket = "s3-20220510" #改成自己的S3儲存桶名稱

def read_image_from_s3(bucket_name, image_name):

    # Connect to the S3 resource with Boto 3
    # get bucket and find object matching image name
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(name=bucket_name)
    Object = bucket.Object(image_name)

    # Downloading the image for display purposes, not necessary for detection of labels
    # You can comment this code out if you don't want to visualize the images
    file_name = Object.key
    

    # get the labels for the image by calling DetectLabels from Rekognition
    client = boto3.client('rekognition', region_name="us-east-1")
    response = client.detect_labels(Image={'S3Object': {'Bucket': bucket_name, 'Name': image_name}},
                                    MaxLabels=10)

    print('Detected labels for ' + image_name)

    full_labels = response['Labels']

    return file_name, full_labels

def get_image_names(name_of_bucket):

    s3_resource = boto3.resource('s3')
    my_bucket = s3_resource.Bucket(name_of_bucket)
    file_list = []
    for file in my_bucket.objects.all():
        file_list.append(file.key)
    return file_list
    
def find_values(id, json_repr):
    results = []

    def _decode_dict(a_dict):
        try:
            results.append(a_dict[id])
        except KeyError:
            pass
        return a_dict

    json.loads(json_repr, object_hook=_decode_dict) # Return value ignored.
    return results

def load_data(image_labels, dynamodb=None):

    if not dynamodb:
        dynamodb = boto3.resource('dynamodb')

    table = dynamodb.Table('Images')

    print("Adding image details:", image_labels)
    table.put_item(Item=image_labels)
    print("Success!!")

def lambda_handler(event, context):
     file_list = get_image_names(bucket)

     for file in file_list:
        file_name = file
        print("Getting labels for " + file_name)
        image_name, image_labels = read_image_from_s3(bucket, file_name)
        image_json_string = json.dumps(image_labels, indent=4)
        labels=set(find_values("Name", image_json_string))
        print("Labels found: " + str(labels))
        labels_dict = {}
        print("Saving label data to database")
        labels_dict["Image"] = str(image_name)
        labels_dict["Labels"] = str(labels)
        print(labels_dict)
        load_data(labels_dict)
        print("Success!")
     
     return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
